package Main;
import ChuyenBay.ChuyenBay;
import ChuyenBay.ChuyenBayManager;
import java.util.Scanner;


public class QuanLyChuyenBay{
    public static void main(String[] args) {
        QuanLyChuyenBay qly = new QuanLyChuyenBay();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nChọn chức năng:");
            System.out.println("1. Thêm chuyến bay");
            System.out.println("2. Xóa chuyến bay");
            System.out.println("3. Sửa chuyến bay");
            System.out.println("4. Hiển thị danh sách chuyến bay");
            System.out.println("5. Lọc chuyến bay theo điểm đi");
            System.out.println("6. Lọc chuyến bay theo hãng bay");
            System.out.println("0. Thoát");
            System.out.print("Nhập lựa chọn của bạn: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Nhập mã chuyến bay: ");
                    String maChuyenBay = scanner.nextLine();
                     System.out.println("Nhập giờ bay");
                     String gioBay = scanner.nextLine();
                     System.out.println("Nhập thời gian bay: ");
                     String tgBay = scanner.nextLine();
                    System.out.print("Nhập điểm đến: ");
                    String diemDen = scanner.nextLine();
                    System.out.print("Nhập ngày bay: ");
                    String ngayBay = scanner.nextLine();
                    System.out.print("Nhập hãng bay: ");
                    String hang = scanner.nextLine();
                    System.out.println("Nhập số ghế: ");
                    int soGhe = scanner.nextInt();
                    ChuyenBay chuyenBay = new ChuyenBay(maChuyenBay, soGhe, ngayBay, gioBay,  tgBay,diemDen,  hang);
                    ChuyenBayManager.themChuyenBay(chuyenBay);
                    break;

                case 2:
                    System.out.print("Nhập mã chuyến bay cần xóa: ");
                    String maXoa = scanner.nextLine();
                    ChuyenBayManager.xoaChuyenBay(maXoa);
                    break;

                case 3:
                    System.out.print("Nhập mã chuyến bay cần sửa: ");
                    String maSua = scanner.nextLine();
                    System.out.print("Nhập điểm đi mới: ");
                    String diemDiMoi = scanner.nextLine();
                    System.out.print("Nhập điểm đến mới: ");
                    String diemDenMoi = scanner.nextLine();
                    System.out.print("Nhập ngày bay mới: ");
                    String ngayBayMoi = scanner.nextLine();
                    System.out.print("Nhập hãng bay mới: ");
                    String hangBayMoi = scanner.nextLine();
                    quanLyChuyenBay.suaChuyenBay(maSua, diemDiMoi, diemDenMoi, ngayBayMoi, hangBayMoi);
                    break;

                case 4:
                    quanLyChuyenBay.hienThiDanhSachChuyenBay();
                    break;

                case 5:
                    System.out.print("Nhập điểm đi cần lọc: ");
                    String diemDiLoc = scanner.nextLine();
                    quanLyChuyenBay.locChuyenBayTheoDiemDi(diemDiLoc);
                    break;

                case 6:
                    System.out.print("Nhập hãng bay cần lọc: ");
                    String hangBayLoc = scanner.nextLine();
                    ChuyenBayManager.locChuyenBayTheoHang(hangBayLoc);
                    break;

                case 0:
                    System.out.println("Thoát chương trình.");
                    return;

                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
            }
        }
    }
}







